/*
 * Copyright (C) 2017 Baidu, Inc. All Rights Reserved.
 */
package com.baidu.aip.face.camera;

public interface PermissionCallback {
    boolean onRequestPermission();
}
