/*
 * Copyright (C) 2017 Baidu, Inc. All Rights Reserved.
 */
package com.baidu.aip.fl.model;

@SuppressWarnings("unused")
public class RegResult extends ResponseResult {

}

